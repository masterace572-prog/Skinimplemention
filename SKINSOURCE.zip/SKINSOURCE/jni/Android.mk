LOCAL_PATH := $(call my-dir)
MAIN_LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE            := libdobby
LOCAL_SRC_FILES         := Dobby/libraries/$(TARGET_ARCH_ABI)/libdobby.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/Dobby/include
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE    := libcurl
LOCAL_SRC_FILES := UltimateFiles/curl/curl-android-arm64-v8a/lib/libcurl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE    := libssl_UltimateFiles
LOCAL_SRC_FILES := UltimateFiles/curl/openssl-android-arm64-v8a/lib/libssl.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE    := libcrypto_UltimateFiles
LOCAL_SRC_FILES := UltimateFiles/curl/openssl-android-arm64-v8a/lib/libcrypto.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := UltimateEngine

LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive

LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive -std=c++17
LOCAL_CPPFLAGS += -DIMGUI_IMPL_OPENGL_ES3 -DGL_GLEXT_PROTOTYPES -DIMGUI_DISABLE_DEMO_WINDOWS

LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all
LOCAL_ARM_MODE := arm

LOCAL_C_INCLUDES := $(MAIN_LOCAL_PATH)
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/backends
LOCAL_C_INCLUDES += $(LOCAL_PATH)/UltimateFiles
LOCAL_C_INCLUDES += $(LOCAL_PATH)/UltimateFiles/curl/curl-android-arm64-v8a/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/UltimateFiles/curl/openssl-android-arm64-v8a/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/SDK
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Dobby/include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Hook
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Hook/Includes
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Hook/KittyMemory
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Hook/And64InlineHook
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Hook/Substrate

LOCAL_SRC_FILES := \
    main.cpp \
    Hook/oxorany.cpp \
    UltimateFiles/base64/base64.cpp \
    imgui/imgui.cpp \
    imgui/imgui_draw.cpp \
    imgui/imgui_tables.cpp \
    imgui/imgui_widgets.cpp \
    imgui/backends/imgui_impl_android.cpp \
    imgui/backends/imgui_impl_opengl3.cpp \
    imgui/backends/android_native_app_glue.c \
    Hook/Substrate/hde64.c \
    Hook/Substrate/SubstrateDebug.cpp \
    Hook/Substrate/SubstrateHook.cpp \
    Hook/Substrate/SubstratePosixMemory.cpp \
    Hook/Substrate/SymbolFinder.cpp \
    Hook/KittyMemory/KittyMemory.cpp \
    Hook/KittyMemory/MemoryPatch.cpp \
    Hook/KittyMemory/MemoryBackup.cpp \
    Hook/KittyMemory/KittyUtils.cpp \
    Hook/And64InlineHook/And64InlineHook.cpp \
    SDK/PUBGM_Basic.cpp \
    SDK/PUBGM_Basic_functions.cpp \
    SDK/PUBGM_Client_functions.cpp \
    SDK/PUBGM_CoreUObject_functions.cpp \
    SDK/PUBGM_Engine_functions.cpp \
    SDK/PUBGM_ShadowTrackerExtra_functions.cpp

LOCAL_CPP_FEATURES := exceptions
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -lGLESv2 -ldl -lz
LOCAL_STATIC_LIBRARIES := libdobby libcurl libssl_UltimateFiles libcrypto_UltimateFiles

include $(BUILD_SHARED_LIBRARY)
