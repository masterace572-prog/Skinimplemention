#pragma once

#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include <vector>
#include <algorithm>
//#include "obfuscate.h"
#include "Logger.h"

typedef unsigned long DWORD;
static uintptr_t libBase;
static bool libLoaded = false;

static DWORD findLibrary(const char *library) {
    char buffer[1024] = {0};
    FILE *fp = fopen("/proc/self/maps", "rt");
    DWORD address = 0;
    if (!fp) return 0;
    while (fgets(buffer, sizeof(buffer), fp)) {
        if (strstr(buffer, library)) {
            address = (DWORD)strtoul(buffer, nullptr, 16);
            break;
        }
    }
    fclose(fp);
    return address;
}

static DWORD getAbsoluteAddress(const char *libraryName, DWORD relativeAddr) {
    libBase = findLibrary(libraryName);
    if (libBase == 0) return 0;
    return (DWORD)(libBase + relativeAddr);
}

static bool isLibraryLoaded(const char *libraryName) {
    char line[512] = {0};
    FILE *fp = fopen("/proc/self/maps", "rt");
    if (!fp) return false;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, libraryName)) {
            fclose(fp);
            libLoaded = true;
            return true;
        }
    }
    fclose(fp);
    return false;
}

static uintptr_t string2Offset(const char *c) {
    if (sizeof(uintptr_t) == sizeof(unsigned long))
        return strtoul(c, nullptr, 16);
    return strtoull(c, nullptr, 16);
}
