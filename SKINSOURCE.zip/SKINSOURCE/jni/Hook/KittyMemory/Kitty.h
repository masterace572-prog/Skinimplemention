// Headers Only
#include <vector>
#include "KittyMemory.h"
#include "MemoryPatch.h"
#include "KittyScanner.h"
#include "KittyUtils.h"

using KittyMemory::ProcMap;
using KittyScanner::RegisterNativeFn;