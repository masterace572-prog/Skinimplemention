#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// AnimBlueprintGeneratedClass ABP_AdditiveAndModify.ABP_AdditiveAndModify_C
// 0x1D15 (0x28D5 - 0x0BC0)
class UABP_AdditiveAndModify_C : public UAdditiveAndModifyAnimInstance
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0BC0(0x0008) (Transient, DuplicateTransient)
	struct FAnimNode_Root                              AnimGraphNode_Root_3B2FCEDC400FCECBDB04F58E8C284206;      // 0x0BC8(0x0050)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_E2E12BF3491E05385F7E34BA6A184C95;// 0x0C18(0x0070)
	struct FAnimNode_RotateRootBone                    AnimGraphNode_RotateRootBone_7EF7FA934657E2268B44B59DC89B7380;// 0x0C88(0x0068)
	struct FAnimNode_BlendListByEnumAdvance            AnimGraphNode_BlendListByEnumAdvance_E82775B041E725925A706A9AA90A479A;// 0x0CF0(0x00F8)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_4E43112548BD78F17B9CAAAED860657B;// 0x0DE8(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_90BCF768405A6B942EE12DB0CCB56214;// 0x0EA8(0x00C0)
	struct FAnimNode_ConvertLocalToComponentSpace      AnimGraphNode_LocalToComponentSpace_3CF52EB14F500580733EF5950C021DCD;// 0x0F68(0x0050)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_E281ABF442EAC5E808BE95B9E0FD3C05;// 0x0FB8(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_C469B50D4FB6773B29CFD292E1638AFB;// 0x1078(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_E31196AB486A62F89FFE5EB80D7D1E66;// 0x1138(0x00C0)
	struct FAnimNode_ConvertComponentToLocalSpace      AnimGraphNode_ComponentToLocalSpace_ACA9BFF54172EA751DA3249AEF87B585;// 0x11F8(0x0050)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_194977304B10933E661031A519DE9F0F;// 0x1248(0x0070)
	struct FAnimNode_MakeDynamicAdditive               AnimGraphNode_MakeDynamicAdditive_35F35EAE483358DFB6BAF88723872216;// 0x12B8(0x0070)
	struct FAnimNode_ApplyMeshSpaceAdditive            AnimGraphNode_ApplyMeshSpaceAdditive_1F7FFB37419BA5AEDBD8BC8DF0F9C4F9;// 0x1328(0x0080)
	struct FAnimNode_LayeredBoneBlend                  AnimGraphNode_LayeredBoneBlend_EE5487584F849631DB12C486CF329D00;// 0x13A8(0x00E8)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_8947FB074B6572F554A548890F94B9E2;// 0x1490(0x0070)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_7B0D021B4B2A53645A0A4A919BF9B109;// 0x1500(0x0070)
	struct FAnimNode_LayeredBoneBlend                  AnimGraphNode_LayeredBoneBlend_5EA1D0D0413C20F7F876F6B5935F678D;// 0x1570(0x00E8)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_559589FB4F13C5C260CF59BA72499D9B;// 0x1658(0x0070)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_F0B04BFF406BE4B23BB9278DD3D60B84;// 0x16C8(0x0070)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_7EDB1BC44BC8C56EE0082F8F95238B4D;// 0x1738(0x00C0)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_2067A2BC4BCAC8B531DDC8A8E024E8A5;// 0x17F8(0x00C0)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_E491A0E641CE8A7EAC3A3989BE02F10A;// 0x18B8(0x0058)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_19AF9EE347D8E1965F0600A3143307A8;// 0x1910(0x0058)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_F9F0B7CF4A4DC12AFEC8358423E78E3C;// 0x1968(0x0058)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_F55793CA48D62C3E42586C9E3747E70E;// 0x19C0(0x0058)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_0750AF8342528C83EB59C3B674B758F6;// 0x1A18(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_9AFFAAD649AB23B0D3323A98A5C28B88;// 0x1AD8(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_03C9C3954BD2EA57919BF98A5F1683F7;// 0x1B98(0x00C0)
	struct FAnimNode_RotateRootBone                    AnimGraphNode_RotateRootBone_D65041094087ADB829A5BEA7EE3B29C4;// 0x1C58(0x0068)
	struct FAnimNode_BlendListByEnumAdvance            AnimGraphNode_BlendListByEnumAdvance_2E11A7F74ADF7EE15195D0BC9A8F1ABF;// 0x1CC0(0x00F8)
	struct FAnimNode_RotateRootBone                    AnimGraphNode_RotateRootBone_62CBB33B4E615C16D1BF1A8EB1ABEFFC;// 0x1DB8(0x0068)
	struct FAnimNode_BlendListByEnumAdvance            AnimGraphNode_BlendListByEnumAdvance_32F702C544F29499891ED49BE9AE0FCD;// 0x1E20(0x00F8)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_08AE10384D8B382A8FE22B84220183C1;// 0x1F18(0x0058)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_443A734C4D028E93E1E1E7B3A90E6879;// 0x1F70(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_C789FBDC445E7703738E83A0F6EB8C85;// 0x2030(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_ABE9B30D403F323128AABC99EC8DBD73;// 0x20F0(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_AA1964274EB7F162C98DBFBDB850850F;// 0x21B0(0x00C0)
	struct FAnimNode_SubInput                          AnimGraphNode_SubInput_852B3FC8453DAAE9710DC7932112B631;  // 0x2270(0x0070)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_08027BE541FD71B009E0AFB834346D16;// 0x22E0(0x00C0)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_2B1B5ED74B83D6C1AC96A8AA1FAC1E5C;// 0x23A0(0x00C0)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_3166FEAA418E6ACA588BB2982CC66D2D;// 0x2460(0x0058)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_A7859C5444A89EC2D44491A2D5E5B06F;// 0x24B8(0x00D0)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_1A8DA5D64D07323681AF90804F285C92;// 0x2588(0x0058)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_BEBEAAD44AE5C385973857A1E20616BD;// 0x25E0(0x0058)
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_D9A7FCCA4ABC6CDAC98C2F97C60DCFE6;// 0x2638(0x00C0)
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_469AC33E4E967102E994F995BF75FB2E;// 0x26F8(0x0058)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_F3D12BE24162D4EAC2E1B9B0AB478EAC;// 0x2750(0x00C0)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_AC14D0B4400408D61965D9852E1EC591;// 0x2810(0x00C0)
	float                                              C_CharacterYawRotateRate_Reverse;                         // 0x28D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<enum EMovementMode>                    C_LastMovementMode;                                       // 0x28D4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass ABP_AdditiveAndModify.ABP_AdditiveAndModify_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_443A734C4D028E93E1E1E7B3A90E6879();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_C789FBDC445E7703738E83A0F6EB8C85();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_ABE9B30D403F323128AABC99EC8DBD73();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_AA1964274EB7F162C98DBFBDB850850F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_BlendListByBool_A7859C5444A89EC2D44491A2D5E5B06F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_F3D12BE24162D4EAC2E1B9B0AB478EAC();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_AC14D0B4400408D61965D9852E1EC591();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_9AFFAAD649AB23B0D3323A98A5C28B88();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_0750AF8342528C83EB59C3B674B758F6();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_SequenceEvaluator_F0B04BFF406BE4B23BB9278DD3D60B84();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_SequenceEvaluator_559589FB4F13C5C260CF59BA72499D9B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_LayeredBoneBlend_5EA1D0D0413C20F7F876F6B5935F678D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_SequenceEvaluator_8947FB074B6572F554A548890F94B9E2();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_LayeredBoneBlend_EE5487584F849631DB12C486CF329D00();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_E31196AB486A62F89FFE5EB80D7D1E66();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_C469B50D4FB6773B29CFD292E1638AFB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_E281ABF442EAC5E808BE95B9E0FD3C05();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_90BCF768405A6B942EE12DB0CCB56214();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_BlendListByEnumAdvance_32F702C544F29499891ED49BE9AE0FCD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_RotateRootBone_62CBB33B4E615C16D1BF1A8EB1ABEFFC();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_BlendListByEnumAdvance_2E11A7F74ADF7EE15195D0BC9A8F1ABF();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_RotateRootBone_D65041094087ADB829A5BEA7EE3B29C4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_BlendListByEnumAdvance_E82775B041E725925A706A9AA90A479A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_RotateRootBone_7EF7FA934657E2268B44B59DC89B7380();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_AdditiveAndModify_AnimGraphNode_ModifyBone_03C9C3954BD2EA57919BF98A5F1683F7();
	void ExecuteUbergraph_ABP_AdditiveAndModify(int EntryPoint);
};


}

