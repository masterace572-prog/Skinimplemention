#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

#include "PUBGM_BangJO.hpp"

namespace SDK
{
//---------------------By BangJO---------------------------
//Parameters
//---------------------By BangJO---------------------------

// Function BP_Ammo_45ACP_Pickup.BP_Ammo_45ACP_Pickup_C.UserConstructionScript
struct ABP_Ammo_45ACP_Pickup_C_UserConstructionScript_Params
{
};

}

