#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_AutoAimingComponent.BP_AutoAimingComponent_C
// 0x0018 (0x0640 - 0x0628)
class UBP_AutoAimingComponent_C : public UWeaponAutoAimingComponent
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x0628(0x0008) (Transient, DuplicateTransient)
	TEnumAsByte<enum EDrawDebugTrace>                  DrawDebugType;                                            // 0x0630(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0631(0x0007) MISSED OFFSET
	class UUserWidget*                                 DebugUI;                                                  // 0x0638(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_AutoAimingComponent.BP_AutoAimingComponent_C");
		return pStaticClass;
	}


	bool CheckInAngle(class ASTExtraBaseCharacter** EnemyPawn, float* MaxAngle);
	bool CheckSmoke(class ASTExtraPlayerCharacter** Pawn, struct FVector* StartPoint, struct FVector* EndPoint, struct FName* OutHitBoneName);
	bool CanEnemeyRaycastReach(class ASTExtraPlayerCharacter** Pawn, struct FVector* StartPoint, struct FVector* EndPoint, struct FName* OutHitBoneName);
	void BPDrawDebugInfo(TArray<float>* AutoAimParams);
	void ExecuteUbergraph_BP_AutoAimingComponent(int EntryPoint);
};


}

