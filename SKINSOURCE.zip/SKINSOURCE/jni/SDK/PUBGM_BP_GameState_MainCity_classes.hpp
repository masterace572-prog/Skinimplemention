#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_GameState_MainCity.BP_GameState_MainCity_C
// 0x0010 (0x15F8 - 0x15E8)
class ABP_GameState_MainCity_C : public AMainCityGameState
{
public:
	class USceneComponent*                             DefaultSceneRoot;                                         // 0x15E8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class ULevelDynamicComponent*                      LevelDynamic;                                             // 0x15F0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_GameState_MainCity.BP_GameState_MainCity_C");
		return pStaticClass;
	}


	void MulticastRPC_SwitchDS(uint64_t MulticastRPC_SwitchDS_param1);
	void __FeatureRPC_ReviveState_MulticastRevivalTimeEnd__();
	void UserConstructionScript();
};


}

