// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

#include "PUBGM_BangJO.hpp"

namespace SDK
{
//---------------------By BangJO---------------------------
//Functions
//---------------------By BangJO---------------------------

// Function BP_GameState_MainCity.BP_GameState_MainCity_C.MulticastRPC_SwitchDS
// (Net, NetReliable, NetMulticast, Public)
// Parameters:
// uint64_t                       MulticastRPC_SwitchDS_param1   (Parm, ZeroConstructor, IsPlainOldData)

void ABP_GameState_MainCity_C::MulticastRPC_SwitchDS(uint64_t MulticastRPC_SwitchDS_param1)
{
	static UFunction *pFunc = nullptr;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_GameState_MainCity.BP_GameState_MainCity_C.MulticastRPC_SwitchDS");

	ABP_GameState_MainCity_C_MulticastRPC_SwitchDS_Params params;
	params.MulticastRPC_SwitchDS_param1 = MulticastRPC_SwitchDS_param1;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function BP_GameState_MainCity.BP_GameState_MainCity_C.#[FeatureRPC(ReviveState.MulticastRevivalTimeEnd)]
// (Net, NetReliable, NetMulticast, Public)

void ABP_GameState_MainCity_C::__FeatureRPC_ReviveState_MulticastRevivalTimeEnd__()
{
	static UFunction *pFunc = nullptr;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_GameState_MainCity.BP_GameState_MainCity_C.#[FeatureRPC(ReviveState.MulticastRevivalTimeEnd)]");

	ABP_GameState_MainCity_C___FeatureRPC_ReviveState_MulticastRevivalTimeEnd___Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function BP_GameState_MainCity.BP_GameState_MainCity_C.UserConstructionScript
// (Event, Public, BlueprintCallable, BlueprintEvent)

void ABP_GameState_MainCity_C::UserConstructionScript()
{
	static UFunction *pFunc = nullptr;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function BP_GameState_MainCity.BP_GameState_MainCity_C.UserConstructionScript");

	ABP_GameState_MainCity_C_UserConstructionScript_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

