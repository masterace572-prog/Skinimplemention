#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

#include "PUBGM_BangJO.hpp"

namespace SDK
{
//---------------------By BangJO---------------------------
//Parameters
//---------------------By BangJO---------------------------

// Function BP_GameState_MainCity.BP_GameState_MainCity_C.MulticastRPC_SwitchDS
struct ABP_GameState_MainCity_C_MulticastRPC_SwitchDS_Params
{
	uint64_t                                           MulticastRPC_SwitchDS_param1;                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function BP_GameState_MainCity.BP_GameState_MainCity_C.#[FeatureRPC(ReviveState.MulticastRevivalTimeEnd)]
struct ABP_GameState_MainCity_C___FeatureRPC_ReviveState_MulticastRevivalTimeEnd___Params
{
};

// Function BP_GameState_MainCity.BP_GameState_MainCity_C.UserConstructionScript
struct ABP_GameState_MainCity_C_UserConstructionScript_Params
{
};

}

