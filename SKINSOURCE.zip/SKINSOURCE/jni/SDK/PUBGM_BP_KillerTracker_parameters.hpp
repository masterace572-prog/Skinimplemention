#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

#include "PUBGM_BangJO.hpp"

namespace SDK
{
//---------------------By BangJO---------------------------
//Parameters
//---------------------By BangJO---------------------------

// Function BP_KillerTracker.BP_KillerTracker_C.UserConstructionScript
struct ABP_KillerTracker_C_UserConstructionScript_Params
{
};

}

