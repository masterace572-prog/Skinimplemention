#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_MachineGun_Vector_10001.BP_MachineGun_Vector_10000_C
// 0x0008 (0x0C38 - 0x0C30)
class ABP_MachineGun_Vector_10000_C : public ABP_LobbyWeapon_C
{
public:
	class ULobbyWeaponAnimList_Rifle_C*                LobbyWeaponAnimList_Rifle;                                // 0x0C30(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_MachineGun_Vector_10001.BP_MachineGun_Vector_10000_C");
		return pStaticClass;
	}


	void UserConstructionScript();
};


}

