#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

#include "PUBGM_BangJO.hpp"

namespace SDK
{
//---------------------By BangJO---------------------------
//Parameters
//---------------------By BangJO---------------------------

// Function BP_MachineGun_Vector_10001.BP_MachineGun_Vector_10000_C.UserConstructionScript
struct ABP_MachineGun_Vector_10000_C_UserConstructionScript_Params
{
};

}

