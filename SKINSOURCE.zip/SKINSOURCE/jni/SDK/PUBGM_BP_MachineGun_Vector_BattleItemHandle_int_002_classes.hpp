#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_MachineGun_Vector_BattleItemHandle_int_002.BP_MachineGun_Vector_BattleItemHandle_int_002_C
// 0x0000 (0x0A41 - 0x0A41)
class UBP_MachineGun_Vector_BattleItemHandle_int_002_C : public UBattleItemHandle_MainWeapon_C
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_MachineGun_Vector_BattleItemHandle_int_002.BP_MachineGun_Vector_BattleItemHandle_int_002_C");
		return pStaticClass;
	}

};


}

