#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_MachineGun_Vector_Wrapper.BP_MachineGun_Vector_Wrapper_C
// 0x0010 (0x0950 - 0x0940)
class ABP_MachineGun_Vector_Wrapper_C : public APickUpWrapperActor
{
public:
	class UStaticMeshComponent*                        StaticMesh;                                               // 0x0940(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UStaticMeshComponent*                        SM_Vector;                                                // 0x0948(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_MachineGun_Vector_Wrapper.BP_MachineGun_Vector_Wrapper_C");
		return pStaticClass;
	}


	void UserConstructionScript();
};


}

