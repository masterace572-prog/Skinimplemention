#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_MachineGun_Vector.BP_MachineGun_Vector_C
// 0x0009 (0x1711 - 0x1708)
class ABP_MachineGun_Vector_C : public ABP_ShootWeaponBase_C
{
public:
	class UWeaponAnimList_MachineGun_Vector_C*         WeaponAnimList_MachineGun_Vector;                         // 0x1708(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bUseIdleAnim_1;                                           // 0x1710(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_MachineGun_Vector.BP_MachineGun_Vector_C");
		return pStaticClass;
	}


	void UserConstructionScript();
};


}

