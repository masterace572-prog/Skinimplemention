#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_MapUIMarkManager.BP_MapUIMarkManager_C
// 0x0000 (0x0530 - 0x0530)
class UBP_MapUIMarkManager_C : public UMapUIMarkManager
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_MapUIMarkManager.BP_MapUIMarkManager_C");
		return pStaticClass;
	}

};


}

