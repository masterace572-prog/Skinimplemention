#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_NightVisionComponent.BP_NightVisionComponent_C
// 0x0000 (0x0C00 - 0x0C00)
class UBP_NightVisionComponent_C : public UNightVisionComponent
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_NightVisionComponent.BP_NightVisionComponent_C");
		return pStaticClass;
	}

};


}

