#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_OBEffectBullet.BP_OBEffectBullet_C
// 0x0010 (0x0520 - 0x0510)
class ABP_OBEffectBullet_C : public AOBEffectBullet
{
public:
	class UParticleSystemComponent*                    P_signal_bullet_01;                                       // 0x0510(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class USceneComponent*                             DefaultSceneRoot;                                         // 0x0518(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_OBEffectBullet.BP_OBEffectBullet_C");
		return pStaticClass;
	}


	void UserConstructionScript();
};


}

