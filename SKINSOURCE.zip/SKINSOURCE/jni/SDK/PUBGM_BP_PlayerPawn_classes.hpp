#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_PlayerPawn.BP_PlayerPawn_C
// 0x02A0 (0x74D0 - 0x7230)
class ABP_PlayerPawn_C : public ASTExtraPlayerCharacter
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x7230(0x0008) (Transient, DuplicateTransient)
	class UStaticMeshComponent*                        ScopeStaticMesh;                                          // 0x7238(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UScopeCameraComponent*                       ScopingCameraNew;                                         // 0x7240(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterFollowComponent_C*                 CharacterFollowComponent;                                 // 0x7248(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterAnimShareParamsComp*               CharacterAnimShareParamsComp;                             // 0x7250(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_PlayEmoteComponent_C*                    BP_PlayEmoteComponent;                                    // 0x7258(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterBoundCapsuleComonent*              MeshBoundCapsuleComonent;                                 // 0x7260(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UDynamicOptimizeCharacterComps_C*            DynamicOptimizeCharacterComps;                            // 0x7268(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_CharacterCarryBackComp_C*                BP_CharacterCarryBackComp;                                // 0x7270(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_SkillManagerComponent_C*                 BP_SkillManagerComponent;                                 // 0x7278(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCustomCameraComponent*                      Camera;                                                   // 0x7280(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCapsuleComponent*                           ShareBounds;                                              // 0x7288(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterAnimList_Skill_C*                  CharacterAnimList_Skill;                                  // 0x7290(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UStaticMeshComponent*                        SCOPE;                                                    // 0x7298(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UPostProcessComponent*                       PostProcess;                                              // 0x72A0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class USpringArmComponent*                         ShoulderCameraSpringArm;                                  // 0x72A8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class USceneComponent*                             ShoulderCameraOffset;                                     // 0x72B0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterAnimList_Base_C*                   CharacterAnimList_Base;                                   // 0x72B8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UPetComponent_BP_C*                          PetComponent_BP;                                          // 0x72C0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterAvatarComp2_BP_C*                  CharacterAvatarComp2_BP;                                  // 0x72C8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UObserverCameraComponent*                    ObserverCameraFPPMode;                                    // 0x72D0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UFPPSpringArmComponent*                      FPPSpringArm;                                             // 0x72D8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UFPPComponent_C*                             FPPComponent;                                             // 0x72E0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UParticleSystemComponent*                    ParticleSystem;                                           // 0x72E8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class USpringArmComponent*                         ScopingSpringArm;                                         // 0x72F0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCapsuleComponent*                           HitBox_Prone;                                             // 0x72F8(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCapsuleComponent*                           HitBox_Stand;                                             // 0x7300(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UVault_Controller_C*                         Vault_Controller;                                         // 0x7308(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_SwimController_C*                        BP_SwimController;                                        // 0x7310(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_AutoAimingComponent_C*                   BP_AutoAimingComponent;                                   // 0x7318(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCharacterWeaponManagerComponent*            CharacterWeaponManager;                                   // 0x7320(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UPickupManagerComponent*                     PickupManager;                                            // 0x7328(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class USceneComponent*                             CameraRoot;                                               // 0x7330(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCustomSpringArmComponent*                   CustomSpringArm;                                          // 0x7338(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCameraSettingComponent_C*                   CameraSettingComponent;                                   // 0x7340(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ScopeTimeline_NewTrack_1_FBCE53A7433799FDD4E08AA77C9DCE27;// 0x7348(0x0004) (ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ETimelineDirection>               ScopeTimeline__Direction_FBCE53A7433799FDD4E08AA77C9DCE27;// 0x734C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x734D(0x0003) MISSED OFFSET
	class UTimelineComponent*                          ScopeTimeline;                                            // 0x7350(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsReloading;                                              // 0x7358(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x7359(0x0003) MISSED OFFSET
	float                                              ReloadingCDMax;                                           // 0x735C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               Jumped;                                                   // 0x7360(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<enum EPlayerCameraMode>                CurCameraMode;                                            // 0x7361(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x7362(0x0002) MISSED OFFSET
	struct FSTR_CameraSetting                          StandCameraSetting;                                       // 0x7364(0x0014) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FVector                                     Normal;                                                   // 0x7378(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x7384(0x0004) MISSED OFFSET
	class APickUpWrapperActor*                         PickUpTarget_1;                                           // 0x7388(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsPicking;                                               // 0x7390(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x7391(0x0003) MISSED OFFSET
	float                                              DefaultCapsuleRadius;                                     // 0x7394(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class USkeletalMeshComponent*                      ParachuteComponent_1;                                     // 0x7398(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<class USpringArmComponent*>                 SpringArms;                                               // 0x73A0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<class UCameraComponent*>                    Cameras;                                                  // 0x73B0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class USpringArmComponent*                         CurActiveSpringArm;                                       // 0x73C0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class USpringArmComponent*                         NewVar_1;                                                 // 0x73C8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<enum ESTEPoseState>                    CurPoseState;                                             // 0x73D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData05[0x7];                                       // 0x73D1(0x0007) MISSED OFFSET
	TMap<int, class UBackpackEmoteHandle*>             EmoteBPIDToAnimHandleMap;                                 // 0x73D8(0x0050) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class UParticleSystem*                             DecentBloodSpot;                                          // 0x7428(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UParticleSystem*                             BloodSpot_Red;                                            // 0x7430(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UParticleSystem*                             BloodSpot_Green;                                          // 0x7438(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<EPawnState>                                 DisallowedWateringStates;                                 // 0x7440(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	class UChildActorComponent*                        PaintDecalDetectComp;                                     // 0x7450(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class ASTExtraWeapon*                              CurUseingEmoteWeapon;                                     // 0x7458(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData)
	class UMaterialBillboardComponent*                 FrameUIBillboard;                                         // 0x7460(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsAngledSightOnlyTurn_1;                                 // 0x7468(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData06[0x7];                                       // 0x7469(0x0007) MISSED OFFSET
	class UMeshComponent*                              OriginAttachComponent;                                    // 0x7470(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UMeshComponent*                              TargetAttachComponent;                                    // 0x7478(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FRotator                                    OriginRotOffset;                                          // 0x7480(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FDollyZoomParam                             OriginDollyZoomParam;                                     // 0x748C(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FDollyZoomParam                             TargetDollyZoomParam;                                     // 0x7498(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char                                      UnknownData07[0x4];                                       // 0x74A4(0x0004) MISSED OFFSET
	struct FName                                       HurtSoundSwitchState;                                     // 0x74A8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     BloodScale;                                               // 0x74B0(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData08[0x4];                                       // 0x74BC(0x0004) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnCakePlacement;                                          // 0x74C0(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, BlueprintAssignable)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_PlayerPawn.BP_PlayerPawn_C");
		return pStaticClass;
	}


	void ShowScreenDamage(float Damage, TEnumAsByte<enum EDamageType> DamageEventType);
	void GetBattleItemHandlePath(int ItemId, struct FString* EmotePath);
	void RefreshWeaponSight();
	void HandleOnLandedSetAutoSprint();
	void ChangeParticleEffect(class UParticleSystemComponent* Particle, const struct FVector& _3DScale);
	void SpawnEmitterEffect(const struct FVector& RelativeLocation, class UParticleSystem* PSRef, class USceneComponent* AttachParent, const struct FVector& RelativeScale);
	struct FString GetEmoteHandlePath(int* ItemId);
	void Replay_IsEnemyFrameUIExisted(bool* bIsExisted);
	void HandleOnLanded(float ForceLandTime);
	void GetGameModeState(struct FName* CurModeState);
	void SetTpCameraFov(float FOV);
	void SetCapsuleParentBounds(bool UseParentBounds);
	void ClearDecalBakingRTCache();
	bool IsAngledSightAvailable();
	void RefreshAngledSightUI(bool HaveAngledSight, bool IsAngledSight);
	void ShowAngledSightState(bool IsAngled);
	void GetAngledSightRotator(class ASTExtraShootWeapon* NewParam, struct FRotator* NewParam1);
	void AngledSightAnimLogic(TEnumAsByte<enum EAngledSightType> Selection);
	void AngledSightAnimUpdate(float InputPin, bool bIsOnlyTurn);
	void Replay_CreateEnemyFrameUI(bool isPlayingCompletePlayback, bool is_enemy);
	void Replay_SetVisiableOfFrameUI(bool is_Visiable);
	void UpdateEmoteWeaponIdInfo(int ID, bool* Ret);
	void AllowWater(bool* bCanEnter);
	bool ShouldRedBlood();
	void CheckHasVehicleAvatar(class ASTExtraVehicleBase* InVehicle, class ASTExtraBaseCharacter* PlayerCharacter, int* InItemID);
	void ChangeCurVehicleAvatar(class ASTExtraVehicleBase* InVehicle);
	void HandleOnChangedVehicleSeat();
	void GetMasterBoneComponent(class UMeshComponent** MasterBoneComponent);
	void InitDefaultAvatarByResID(int AGender, int Head, int hair);
	void GetGrenadeCameraShakeByDir(const struct FVector& ImpulseDir, class UClass** RetVar);
	class UBackpackEmoteHandle* GetEmoteHandle(int* ItemId);
	struct FString GetShootWeaponNameByWeapon(int* ItemDefineID);
	class UCameraComponent* GetThirdPersonCamera();
	class USpringArmComponent* GetThirdPersonSpringArm();
	class UCameraComponent* GetFPPCamera();
	class USpringArmComponent* GetFPPSpringArm();
	class UCameraComponent* GetFirstPersonCamera();
	class USpringArmComponent* GetFirstPersonSpringArm();
	class UCameraComponent* GetScopeCamera();
	class USpringArmComponent* GetScopeSpringArm();
	bool ShouldAutoScopeWhenPeek();
	void GetControllerViewCamera(class UCameraComponent** Camera);
	void HandleOnDetachedVehicle(class ASTExtraVehicleBase* NewParam);
	void HandleOnAttachedVehicle(class ASTExtraVehicleBase* InVehicle);
	class USpringArmComponent* GetActiveSpringArm();
	void AimInterupted();
	void GetWeapon(struct FVector* NewParam, struct FRotator* NewParam1, bool* bHaveWeapon);
	void ResetBPCameraSetting();
	void ShowDebugArrow(class USceneComponent* self2, const struct FRotator& InRot, const struct FLinearColor& Color);
	void IsAutonomous(bool* NewParam);
	void PickUp(class APickUpWrapperActor* NewParam);
	void DoPickUpTarget();
	void RotateMesh(const struct FRotator& NewParam);
	void SetAllCollisionEnabled(bool bEnable);
	void MoveOutScope();
	void MoveInScope();
	void Reload();
	void SwitchCrouch(TEnumAsByte<enum ESTEPoseState> NewParam, TEnumAsByte<enum ESTEPoseState> preState);
	void UserConstructionScript();
	void ScopeTimeline__FinishedFunc();
	void ScopeTimeline__UpdateFunc();
	void OnPetOwnerPossessed();
	void ReceiveBeginPlay();
	void BPNotifyStartDying(class AController** Killer, class AActor** DamageCauser, struct FHitResult* KillingHitInfo, struct FVector* KillingHitImpulseDir, class UClass** KillingHitDamageType);
	void ReloadEvent();
	void OnEquipWeapon(TEnumAsByte<enum ESurviveWeaponPropSlot>* Slot);
	void OnNotifyHurt();
	void OnLanded(struct FHitResult* Hit);
	void OnPoseStateChange(TEnumAsByte<enum ESTEPoseState>* LastState, TEnumAsByte<enum ESTEPoseState>* CurState);
	void BPReceiveDamage(float* Damage, class UDamageType** DamageType, class AController** InstigatedBy, class AActor** DamageCauser, TEnumAsByte<enum EDamageType>* DamageEventType);
	void ParachuteOnWater();
	void OnUnEquipWeapon();
	void PawnVaultServerBluePrint(float* dis, float* Height, float* Length, struct FString* VaultKey, struct FVector* StartPos, class AActor** checkActor, float* crossblockMaxFall, float* crossblockMaxDis, struct FVector* HitPoint, class AActor** WindowActor, struct FRotator* movedir);
	void PawnVaultAllBluePrint(float* dis, float* Height, float* Length, struct FString* VaultKey, struct FVector* StartPos, class AActor** checkActor, float* crossblockMaxFall, float* crossblockMaxDis, struct FVector* HitPoint, struct FRotator* movedir);
	void ScopeInStop();
	void PlayScopeInTimeline(float Rate);
	void BPReceiveRadialDamage(float* DamageReceived, class UDamageType** DamageType, struct FVector* Origin, float* Radius, struct FHitResult* HitInfo, class AController** InstigatedBy, class AActor** DamageCauser, struct FVector* ImpulseDir);
	void ReceivePossessed(class AController** NewController);
	void ParachutePlaySound(class UAkAudioEvent** LocalAkEvent, class UAkAudioEvent** RemoteAkEvent);
	void OnWeaponEquipmentUpdate();
	void BindAndExecStateChanged();
	void StateEnterHandler_Event_1(EPawnState State);
	void OnHitByCake();
	void EnablePet(bool* Enable);
	void OnEnterStateForBp(EPawnState* State);
	void OnLeaveStateForBp(EPawnState* State);
	void ReceiveDestroyed();
	void PawnVaultServerStopCheckBluePrint();
	void PawnVaultStopBluePrint();
	void SwitchSightAngledLocal(TEnumAsByte<enum EAngledSightType>* Type, bool* IsOnlyTurn);
	void DoAngledSight(bool IsPush);
	void DoNormalSight(bool IsPush);
	void StopSwitchAngledSight();
	void CustomEvent_4(class ASTExtraShootWeapon* Weapon, EWeaponAttachmentSocketType Type, bool bEquip);
	void CustomEvent_1(bool bIsBegin);
	void OnVehicleStateChange();
	void OnBPStateCheckIn();
	void LuaReceiveBeginPlay();
	void SwitchRearSight(int PrevIndex, int NewIndex, const struct FRotator& AngleRotator);
	void BPOnRespawned();
	void RemoveRemainingCameraBlood(int SeatType);
	void DoWeaponSight();
	void SetWeaponSightStateLocal(bool* IsOpenWeaponSight);
	void RearSightTimeLineUpdate(float* Alpha);
	void RearSightTimeLineFinish(int* InRearSightNewIndex);
	void AngleSightTimeLineUpdate(float* Alpha);
	void AngleSightTimeLineFinish();
	void DoAutoReloadCurrentWeapon(class ASTExtraShootWeapon** ShootWeapon);
	void ExecuteUbergraph_BP_PlayerPawn(int EntryPoint);
	void OnCakePlacement__DelegateSignature(bool Success);
};


}

