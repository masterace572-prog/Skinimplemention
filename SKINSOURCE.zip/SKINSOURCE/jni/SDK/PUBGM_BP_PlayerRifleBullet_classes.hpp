#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_PlayerRifleBullet.BP_PlayerRifleBullet_C
// 0x0008 (0x08E8 - 0x08E0)
class ABP_PlayerRifleBullet_C : public ASTExtraShootWeaponBulletBase
{
public:
	class UStaticMeshComponent*                        BulletMesh;                                               // 0x08E0(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_PlayerRifleBullet.BP_PlayerRifleBullet_C");
		return pStaticClass;
	}


	void UserConstructionScript();
};


}

