#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_PlayerRifleCameraShakeNormal.BP_PlayerRifleCameraShakeNormal_C
// 0x0000 (0x0160 - 0x0160)
class UBP_PlayerRifleCameraShakeNormal_C : public UCameraShake
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_PlayerRifleCameraShakeNormal.BP_PlayerRifleCameraShakeNormal_C");
		return pStaticClass;
	}

};


}

