#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Classes
//---------------------By BangJO---------------------------

// BlueprintGeneratedClass BP_STExtraWheeledVehicle.BP_STExtraWheeledVehicle_C
// 0x0067 (0x2167 - 0x2100)
class ABP_STExtraWheeledVehicle_C : public ASTExtraWheeledVehicle
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x2100(0x0008) (Transient, DuplicateTransient)
	class UBP_VehicleMusic_C*                          BP_VehicleMusic;                                          // 0x2108(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UWheeledVehicleProtectionComponent*          VehicleProtection;                                        // 0x2110(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBP_VehicleShowFrameComp_C*                  BP_VehicleShowFrameComp;                                  // 0x2118(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UVehicleAvatarComponent_BP_C*                VehicleAvatarComponent_BP;                                // 0x2120(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCameraComponent*                            Camera;                                                   // 0x2128(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UVehicleSpringArmComponent*                  VehicleSpringArm;                                         // 0x2130(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               IsPlayingEngineAk;                                        // 0x2138(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x2139(0x0007) MISSED OFFSET
	struct FName                                       TailLightParamName;                                       // 0x2140(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       FrontLightParamName;                                      // 0x2148(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName                                       FPPBoostLightParamName;                                   // 0x2150(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bEngineStarted;                                           // 0x2158(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x2159(0x0003) MISSED OFFSET
	float                                              LastOverlapShakeTime;                                     // 0x215C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              OverlapShakeInterval;                                     // 0x2160(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bLobbyShow;                                               // 0x2164(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bInvincibleProtect;                                       // 0x2165(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               EnableLightEffect;                                        // 0x2166(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = nullptr;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass BP_STExtraWheeledVehicle.BP_STExtraWheeledVehicle_C");
		return pStaticClass;
	}


	void OnClientVehicleHealthStateChangedToDestory();
	void CreateDMI();
	void SetDMIParam(class UMaterialInstanceDynamic* Dim, const struct FName& Name, float Value);
	void UpdateExhaustFx(const struct FName& ExhaustName);
	void UserConstructionScript();
	void OnEngineStart();
	void OnEngineStop();
	void ReceiveBeginPlay();
	void OnSetTailLightValue(float* LightValue);
	void OnBoostingChanged();
	void VehicleMeshChanged();
	void BPPlayOverlapDamageCameraShake();
	void ReceiveActorBeginOverlap(class AActor** OtherActor);
	void AdvanceVehicleMeshChanged();
	void ExecuteUbergraph_BP_STExtraWheeledVehicle(int EntryPoint);
};


}

