#pragma once

// PUBGm - 64bit (4.3.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_BPMappingTable_type.BP_STRUCT_BPMappingTable_type
// 0x0038
struct FBP_STRUCT_BPMappingTable_type
{
	struct FString                                     BPMapping_0_359D8E805EAA95B608F926810D8E6097;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_53343E0047BD3A720C3CF0DE04726144;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     DependPath_3_269ACE405F922C993E0095690CDABC28;            // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ActorMapping_4_57DC08407CB974393F1F63C300853947;          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

